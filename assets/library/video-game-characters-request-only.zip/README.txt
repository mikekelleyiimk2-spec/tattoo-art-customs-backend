VIDEO GAME CHARACTERS — REQUEST ONLY
=====================================
Tattoo Art Customs private collection.

These are the character art pieces for the video game background series:
- linework/ — black linework versions (19 designs)
- color/ — full-color versions of the exact same drawings (19 designs)

REQUEST-ONLY: these are trademarked/copyrighted game characters. They are
NOT posted on the public website. They are delivered to customers by custom
request only, through the custom order flow — same as the other request-only
character designs.

The matching backgrounds (character-free scenes) are sold as regular premade
designs on the site. Each character is drawn full-body on plain white so it
can be composited onto its game's background.

Missing from this set: Sonic the Hedgehog and The Last of Us (Joel + Ellie)
character art could not be generated — backgrounds for those games are still
available on the site.
